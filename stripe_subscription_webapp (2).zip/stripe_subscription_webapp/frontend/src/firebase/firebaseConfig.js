import firebase from "firebase/compat/app"
import "firebase/compat/auth"
import "firebase/compat/database"

const firebaseConfig = {
    apiKey: "AIzaSyArrrosiWwkbQtBMNXPw4JW81ZUbhGk4-w",
    authDomain: "subscribe-6e800.firebaseapp.com",
    projectId: "subscribe-6e800",
    storageBucket: "subscribe-6e800.appspot.com",
    messagingSenderId: "122623815904",
    appId: "1:122623815904:web:7eff6b053cbe83e864e085"
};

if(!firebase.apps.length){
    firebase.initializeApp(firebaseConfig)
}

export default firebase